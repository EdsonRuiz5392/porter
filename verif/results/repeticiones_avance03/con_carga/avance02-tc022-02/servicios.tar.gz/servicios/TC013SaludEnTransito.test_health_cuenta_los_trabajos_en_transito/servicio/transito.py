
import asyncio, json, os, sqlite3, sys
sys.path.insert(0, sys.argv[1])
from src.servicio import bitacora, operacion, persistencia
from src.servicio.gestion_trabajos import cola, control, launcher

class LauncherLento(launcher.Launcher):
    async def start(self, *a, **kw):
        await asyncio.sleep(2)                   # ensancha la ventana de arranque
        return await super().start(*a, **kw)

async def main():
    data = sys.argv[2]
    os.makedirs(data + "/output", exist_ok=True)
    c = control.Control(cola=cola.Cola(10), launcher=LauncherLento(),
                        persistencia=persistencia.Persistencia(data + "/jobs.db"),
                        bitacora=bitacora.Bitacora(data + "/jobrunner.log"),
                        max_concurrency=1, grace_seconds=1, data_dir=data)
    j = await c.submit(command="true", args=[], client_request_id=None)
    await asyncio.sleep(0.5)
    h = await operacion.health_summary(c)
    base = sqlite3.connect(data + "/jobs.db").execute(
        "select status from jobs where id=?", (j.id,)).fetchone()[0]
    print(json.dumps({"running": h["running"], "queued": h["queued"],
                      "starting": h.get("starting"), "base": base}), flush=True)
    await asyncio.sleep(3)
asyncio.run(main())
