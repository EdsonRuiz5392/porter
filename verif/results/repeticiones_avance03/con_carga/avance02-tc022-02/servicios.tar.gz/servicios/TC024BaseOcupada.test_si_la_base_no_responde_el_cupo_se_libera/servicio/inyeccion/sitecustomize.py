
import os, sqlite3
_t = float(os.environ.get("JR_SQLITE_TIMEOUT", "0") or 0)
if _t:
    _orig = sqlite3.connect
    def connect(*a, **kw):
        kw["timeout"] = _t
        return _orig(*a, **kw)
    sqlite3.connect = connect
