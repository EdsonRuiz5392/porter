
import asyncio, os, sys
sys.path.insert(0, sys.argv[1])
from src.servicio import bitacora, persistencia
from src.servicio.gestion_trabajos import cola, control, launcher

class LauncherQueSeCuelga(launcher.Launcher):
    async def start(self, *a, **kw):
        proc = await super().start(*a, **kw)
        print("LANZADO", proc.pid, flush=True)
        await asyncio.Event().wait()        # nunca regresa: mark_running no llega

async def main():
    data = sys.argv[2]
    os.makedirs(data + "/output", exist_ok=True)
    c = control.Control(cola=cola.Cola(10), launcher=LauncherQueSeCuelga(),
                        persistencia=persistencia.Persistencia(data + "/jobs.db"),
                        bitacora=bitacora.Bitacora(data + "/jobrunner.log"),
                        max_concurrency=1, grace_seconds=1, data_dir=data)
    await c.submit(command="bash", args=["-c", "echo x >> " + sys.argv[3] + "; sleep 341"],
                   client_request_id=None)
    await asyncio.Event().wait()
asyncio.run(main())
